const chalk = require("chalk")
const fs = require("fs")

//______________________[ PERLENGKAPAN ]_______________________//
global.owner = '6282376666188' //Ganti Jadi No Lu
global.ownerku = ['6282376666188']
global.ownerNomor = '6282376666188'
global.botname = 'ARIE PULSA' //Ganti Jadi Nama Bot Lu
global.namabot = 'NC PULSA' 
global.ownername = 'NC PULSA' 
global.ownerName = 'NC PULSA' //Ganti Jadi Nama Lu
global.footer = 'NcPulsa'
global.packname = `BotWa` 
global.struk = `NcPulsa` 
global.toko = `©CV ROOT NET DIGITAL`
global.youtube = `@rootnet87`
global.sessionName = `nc`
global.wlcm = []
global.wlcmm = []
global.anticall = true
global.antilink = false
global.prefa = ['-_-']

//______________________[ THUMBNAIL ]_______________________//
global.qris = fs.readFileSync("./image/qris.png") //Sesuaikan Dengan Nama Gambar Qris Di Folder Image

//______________________[ GC MEMBER ]_______________________//
global.gcresmi = 'https://chat.whatsapp.com/LSCxKfjTlEq5E1Cw9oIxh3' //Ganti Dengan Link Groupmu

//______________________[ DATA REKENING ]_______________________//
global.rekening = `

》 SCAN QRIS HANYA UNTUK DANA SELAIN DANA UANG AKAN DITAHAN 1x24 JAM

》 Silahkan Transfer Ke Salah Satu Rekening
》 DANA/SHOPEE/GOPAY : 085174332383
》 MANDIRI : 1050014470409
》 BRI : 109201031246504
》 BCA : 8645201597
》 SEABANK : 901836805900
》 JENIUS / BTPN : 90370370861
》 BANK JAGO : 109313643765
》 *ATAS NAMA : RIZKI SAPUTRA*

`

global.mess = {
    wait: 'Sedang DiProses',
    succes: 'Sukses',
    admin: 'Layanan Khsusus Admin',
    botAdmin: 'BOT Harus Jadi Admin',
    owner: 'Layanan Khusus Owner',
    group: 'Hanya Bisa Didalam Group',
    private: 'Silahkan Private Chat Dengan BOT',
    bot: 'Fitur Special BOT',
    error: 'Layanan Error',    
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})