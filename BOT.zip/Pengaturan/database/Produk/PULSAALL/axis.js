const list7 = {
  "axis": {   
    "AXIS5": {
    "nama": "Pulsa Axis 5.000",
    "hargaid": 6500,
    "harga":"Rp6.500",
    },       
        "AXIS15": {
    "nama": "Pulsa Axis 15.000",
    "hargaid": 15780,
    "harga":"Rp15.780",
    },
        "AXIS20": {
    "nama": "Pulsa Axis 20.000",
    "hargaid": 20780,
    "harga":"Rp20.780",
    },     
    "AXIS30": {
    "nama": "Pulsa Axis 30.000",
    "hargaid": 30780,
    "harga":"Rp30.780",
    },   
        "AXIS50": {
    "nama": "Pulsa Axis 50.000",
    "hargaid": 50780,
    "harga":"Rp50.780",
    },     
        "AXIS200": {
    "nama": "Pulsa Axis 200.000",
    "hargaid": 200780,
    "harga":"Rp200.780",
    },            
},
};

module.exports = { list7 }

