const list13 = {
  "byu": {   
    "BY5": {
    "nama": "Pulsa byU 5.000",
    "hargaid": 5805,
    "harga":"Rp5805",
    },       
        "BY10": {
    "nama": "Pulsa byU 10.000",
    "hargaid": 10780,
    "harga":"Rp10780",
    },
        "BY15": {
    "nama": "Pulsa byU 15.000",
    "hargaid": 15780,
    "harga":"Rp15.780",
    },     
    "BY20": {
    "nama": "Pulsa byU 20.000",
    "hargaid": 20780,
    "harga":"Rp20.780",
    },   
        "BY25": {
    "nama": "Pulsa byU 25.000",
    "hargaid": 25780,
    "harga":"Rp25.780",
    },     
        "BY30": {
    "nama": "Pulsa byU 30.000",
    "hargaid": 30780,
    "harga":"Rp30.780",
    },            
    "BY35": {
    "nama":"Pulsa byU 35.000",
    "hargaid": 35780,
    "harga":"Rp35.780",
    },
    "BY40": {
    "nama":"Pulsa byU 40.000",
    "hargaid": 40780,
    "harga":"Rp40.780",
    },
    "BY45": {
    "nama":"Pulsa byU 45.000",
    "hargaid": 45780,
    "harga":"Rp45.780",
    },
    "BY50": {
    "nama":"Pulsa byU 50.000",
    "hargaid": 50780,
    "harga":"Rp50.780",
    },
    "BY55": {
    "nama":"Pulsa byU 55.000",
    "hargaid": 50780,
    "harga":"Rp55.780",
    },
    "BY60": {
    "nama":"Pulsa byU 60.000",
    "hargaid": 60780,
    "harga":"Rp60.780",
    },
    "BY65": {
    "nama":"Pulsa byU 65.000",
    "hargaid": 65780,
    "harga":"Rp65.780",
    },
    "BY70": {
    "nama":"Pulsa byU 70.000",
    "hargaid": 70780,
    "harga":"Rp70.780",
    },
    "BY75": {
    "nama":"Pulsa byU 75.000",
    "hargaid": 75780,
    "harga":"Rp75.780",
    },
    "BY80": {
    "nama":"Pulsa byU 80.000",
    "hargaid": 80780,
    "harga":"Rp80.780",
    },
    "BY85": {
    "nama":"Pulsa byU 85.000",
    "hargaid": 85780,
    "harga":"Rp85.780",
    },
    "BY90": {
    "nama":"Pulsa byU 90.000",
    "hargaid": 90780,
    "harga":"Rp90.780",
    },
     "BY95": {
   "nama":"Pulsa byU 95.000",
   "hargaid": 95780,
   "harga":"Rp95.780",
       
    },
    "BY100": {
    "nama":"Pulsa byU 100.000",
    "hargaid": 100780,
    "harga":"Rp100.780",
    },
    "BY150": {
    "nama":"Pulsa byU 150.000",
    "hargaid": 150780,
    "harga":"Rp150.780",
    },
  },
};

module.exports = { list13 }

