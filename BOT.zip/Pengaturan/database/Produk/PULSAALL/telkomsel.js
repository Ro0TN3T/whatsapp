const list8 = {
  "telkomsel": {   
    "TKL5": {
    "nama": "Pulsa Telkomsel 5.000",
    "hargaid": 5740,
    "harga":"Rp5.740",
    },
        "TKL10": {
    "nama": "Pulsa Telkomsel 10.000 ",
    "hargaid": 10730,
    "harga":"Rp10.730",
    },
        "TKL15": {
    "nama": "Pulsa Telkomsel 15.000",
    "hargaid": 15680,
    "harga":"Rp15.680",
    },
        "TKL20": {
    "nama": "Pulsa Telkomsel 20.000",
    "hargaid": 20680,
    "harga":"Rp20.680",
    },
       "TKL25": {
    "nama": "Pulsa Telkomsel 25.000",
    "hargaid": 25680,
    "harga":"Rp25.680",
    },
    "TKL30": {
    "nama": "Pulsa Telkomsel 30.000",
    "hargaid": 30680,
    "harga":"Rp30.680",
    },
    "TKL35": {
    "nama":"Pulsa Telkomsel 35.000",
    "hargaid": 35680,
    "harga":"Rp35.680",
    },
    "TKL40": {
    "nama": "Pulsa Telkomsel 40.000",
    "hargaid": 40680,
    "harga":"Rp40.680",
    },
    "TKL45": {
    "nama":"Pulsa Telkomsel 45.000",
    "hargaid": 45680,
    "harga":"Rp45.680",
    },
        "TKL50": {
    "nama": "Pulsa Telkomsel 50.000",
    "hargaid": 50680,
    "harga":"Rp50.680",
    },
    "TKL55": {
    "nama":"Pulsa Telkomsel 55.000",
    "hargaid": 55680,
    "harga":"Rp55.680",
    },
    "TKL60": {
    "nama": "Pulsa Telkomsel 60.000",
    "hargaid": 60680,
    "harga":"Rp60.680",
    },
    "TKL65": {
    "nama":"Pulsa Telkomsel 65.000",
    "hargaid": 65680,
    "harga":"Rp65.680",
    },
    "TKL70": {
    "nama": "Pulsa Telkomsel 70.000",
    "hargaid": 70680,
    "harga":"Rp70.680",
    },
    "TKL75": {
    "nama":"Pulsa Telkomsel 75.000",
    "hargaid": 75680,
    "harga":"Rp75.680",
    },
    "TKL80": {
    "nama": "Pulsa Telkomsel 80.000",
    "hargaid": 80680,
    "harga":"Rp80.680",
    },
    "TKL85": {
    "nama":"Pulsa Telkomsel 85.000",
    "hargaid": 85680,
    "harga":"Rp80.680",
    },
    "TKL90": {
    "nama": "Pulsa Telkomsel 90.000",
    "hargaid": 90680,
    "harga":"Rp90.680",
    },
    "TKL95": {
    "nama":"Pulsa Telkomsel 95.000",
    "hargaid": 95680,
    "harga":"Rp95.680",
    },
        "TKL100": {
    "nama": "Pulsa Telkomsel 100.000",
    "hargaid": 100680,
    "harga":"Rp100.680",
    }, 
  "TKL150": {
  "nama":"Pulsa Telkomsel 150.000",
  "hargaid": 150680,
  "harga":"Rp150.680",
   },          
 },
};

module.exports = { list8 }

