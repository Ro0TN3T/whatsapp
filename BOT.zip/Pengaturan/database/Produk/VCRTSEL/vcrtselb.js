const list42 = {
  "vcrtselb": {   
    "VCTSELB1": {
    "nama": "Voucher Telkomsel 1 GB / 3 Hari (Bali-Nusa Tenggara Zona2) (Kode:1)",
    "hargaid": 10000, 
    "harga":"Rp10.000",
    },       
    "VCTSELB2": {
    "nama": "Voucher Telkomsel 1.5 GB / 5 Hari (Bali-Nusa Tenggara Zona2) (Kode:2)",
    "hargaid": 15000, 
    "harga":"Rp15.000",
    },       
    "VCTSELB3": {
    "nama": "Voucher Telkomsel 10 GB / 30 Hari (Bali-Nusa Tenggara Zona2) (Kode:3)",
    "hargaid": 95000, 
    "harga":"Rp95.000",
    },       
    "VCTSELB4": {
    "nama": "Voucher Telkomsel 14 GB / 30 Hari (Bali-Nusa Tenggara Zona2) (Kode:4)",
    "hargaid": 115000, 
    "harga":"Rp115.000",
    },       
    "VCTSELB5": {
    "nama": "Voucher Telkomsel 2.5 GB / 7 Hari (Bali-Nusa Tenggara Zona2) (Kode:5)",
    "hargaid": 25000, 
    "harga":"Rp25.000",
    },       
    "VCTSELB6": {
    "nama": "Voucher Telkomsel 3.75 GB / 5 Hari (Bali-Nusa Tenggara Zona2) (Kode:6)",
    "hargaid": 29000, 
    "harga":"Rp29.000",
    },       
    "VCTSELB7": {
    "nama": "Voucher Telkomsel 4 GB / 30 Hari (Bali-Nusa Tenggara Zona2) (Kode:7)",
    "hargaid": 49000, 
    "harga":"Rp49.000",
    },      
    "VCTSELB8": {
    "nama": "Voucher Telkomsel 5 GB / 5 Hari (Bali-Nusa Tenggara Zona2) (Kode:8)",
    "hargaid": 32000, 
    "harga":"Rp32.000",
    },       
},
};

module.exports = { list42 }

