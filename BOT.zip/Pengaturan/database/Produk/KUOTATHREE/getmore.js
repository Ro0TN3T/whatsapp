const list26 = {
  "getmore": {   
    "GE4": {
    "nama": "Tri Data GetMore 4 GB / 30 Hari (Kode:4)",
    "hargaid": 20500, 
    "harga":"Rp20.500",
    },       
    "GE8": {
    "nama":"Tri Data GetMore 8 GB / 30 Hari (Kode:8)",
    "hargaid": 32000,
    "harga":"Rp32.000",
    },
    "GE10": {
    "nama":"Tri Data GetMore 10 GB / 30 Hari (Kode:10)",
    "hargaid": 38600,
    "harga":"Rp38.600",
    },
},
};

module.exports = { list26 }

