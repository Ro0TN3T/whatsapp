const list2 = {
  "ovo": {   
        "OVO10": {
    "nama": "OVO 10.000 ",
    "hargaid": 11500,
    "harga":"Rp11.500",
    },
        "OVO15": {
    "nama": "OVO 15.000",
    "hargaid": 16500,
    "harga":"Rp16.500",
    },
        "OVO20": {
    "nama": "OVO 20.000",
    "hargaid": 21500,
    "harga":"Rp21.500",
    },
        "OVO25": {
    "nama": "OVO 25.000",
    "hargaid": 26500,
    "harga":"Rp26.500",
    },
        "OVO30": {
    "nama": "OVO 30.000",
    "hargaid": 31500,
    "harga":"Rp31.500",
    },     
       "OVO35": {
    "nama": "OVO 35.000",
    "hargaid": 36500,
    "harga":"Rp36.500",
    },     
       "OVO40": {
    "nama": "OVO 40.000",
    "hargaid": 41500,
    "harga":"Rp41.500",
    },     
       "OVO45": {
    "nama": "OVO 45.000",
    "hargaid": 46500,
    "harga":"Rp46.500",
    },     
      "OVO50": {
    "nama": "OVO 50.000",
    "hargaid": 51500,
    "harga":"Rp51.500",
    },     
   "OVO55": {
    "nama": "OVO 55.000",
    "hargaid": 56.500,
    "harga":"Rp56.500",
    },     
   "OVO60": {
    "nama": "OVO 60.000",
    "hargaid": 61.500,
    "harga":"Rp61.500",
    },     
   "OVO65": {
    "nama": "OVO 65.000",
    "hargaid": 66500,
    "harga":"Rp66.500",
    },     
   "OVO70": {
    "nama": "OVO 70.000",
    "hargaid": 71500,
    "harga":"Rp71.500",
    },     
    "OVO75": {
    "nama": "OVO 75.000",
    "hargaid": 76500,
    "harga":"Rp76.500",
    },     
   "OVO80": {
    "nama": "OVO 80.000",
    "hargaid": 81500,
    "harga":"Rp81.500",
    },     
   "OVO85": {
    "nama": "OVO 85.000",
    "hargaid": 86500,
    "harga":"Rp86.500",
    },     
   "OVO90": {
    "nama": "OVO 90.000",
    "hargaid": 91500,
    "harga":"Rp91.500",
    },     
   "OVO95": {
    "nama": "OVO 95.000",
    "hargaid": 96500,
    "harga":"Rp96.500",
    },     
   "OVO100": {
    "nama": "OVO 100.000",
    "hargaid": 101500,
    "harga":"Rp101.500",
    },     
   "OVO200": {
    "nama": "OVO 200.000",
    "hargaid": 201500,
    "harga":"Rp201.500",
    },     
},
};

module.exports = { list2 }