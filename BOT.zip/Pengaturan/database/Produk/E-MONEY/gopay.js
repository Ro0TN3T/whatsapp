const list1 = {
  "gopay": {   
    "GOPAY5": {
    "nama": "Gopay 5.000",
    "hargaid": 6200,
    "harga":"Rp6.200",
    },
        "GOPAY10": {
    "nama": "Gopay 10.000 ",
    "hargaid": 11200,
    "harga":"Rp11.200",
    },
        "GOPAY15": {
    "nama": "Gopay 15.000",
    "hargaid": 16200,
    "harga":"Rp16.200",
    },
        "GOPAY20": {
    "nama": "Gopay 20.000",
    "hargaid": 21200,
    "harga":"Rp21.200",
    },
        "GOPAY25": {
    "nama": "Gopay 25.000",
    "hargaid": 26200,
    "harga":"Rp26.200",
    },
        "GOPAY30": {
    "nama": "Gopay 30.000",
    "hargaid": 31200,
    "harga":"Rp31.200",
    },     
       "GOPAY35": {
    "nama": "Gopay 35.000",
    "hargaid": 36200,
    "harga":"Rp36.200",
    },     
       "GOPAY40": {
    "nama": "Gopay 40.000",
    "hargaid": 41200,
    "harga":"Rp41.200",
    },     
       "GOPAY45": {
    "nama": "Gopay 45.000",
    "hargaid": 46200,
    "harga":"Rp46.200",
    },     
      "GOPAY50": {
    "nama": "Gopay 50.000",
    "hargaid": 51200,
    "harga":"Rp51.200",
    },     
   "GOPAY55": {
    "nama": "Gopay 55.000",
    "hargaid": 56200,
    "harga":"Rp56.200",
    },     
   "GOPAY60": {
    "nama": "Gopay 60.000",
    "hargaid": 61200,
    "harga":"Rp61.200",
    },     
   "GOPAY65": {
    "nama": "Gopay 65.000",
    "hargaid": 66200,
    "harga":"Rp66.200",
    },     
   "GOPAY70": {
    "nama": "Gopay 70.000",
    "hargaid": 71200,
    "harga":"Rp71.200",
    },     
    "GOPAY75": {
    "nama": "Gopay 75.000",
    "hargaid": 76200,
    "harga":"Rp76.200",
    },     
   "GOPAY80": {
    "nama": "Gopay 80.000",
    "hargaid": 81200,
    "harga":"Rp81.200",
    },     
   "GOPAY85": {
    "nama": "Gopay 85.000",
    "hargaid": 86200,
    "harga":"Rp86.200",
    },     
   "GOPAY90": {
    "nama": "Gopay 90.000",
    "hargaid": 91200,
    "harga":"Rp91.200",
    },     
   "GOPAY95": {
    "nama": "Gopay 95.000",
    "hargaid": 96200,
    "harga":"Rp96.200",
    },     
   "GOPAY100": {
    "nama": "Gopay 100.000",
    "hargaid": 101200,
    "harga":"Rp101.200",
    },     
   "GOPAY200": {
    "nama": "Gopay 200.000",
    "hargaid": 201200,
    "harga":"Rp201.200",
    },     
},
};

module.exports = { list1 }