const list3 = {
  "shopeepay": {   
    "SHPI5": {
    "nama": "Shopee Pay 5.000",
    "hargaid": 6500,
    "harga":"Rp6.500",
    },
        "SHPI10": {
    "nama": "Shopee Pay 10.000 ",
    "hargaid": 11500,
    "harga":"Rp11.500",
    },
        "SHPI15": {
    "nama": "Shopee Pay 15.000",
    "hargaid": 16.500,
    "harga":"Rp16.500",
    },
        "SHPI20": {
    "nama": "Shopee Pay 20.000",
    "hargaid": 21500,
    "harga":"Rp21.500",
    },
        "SHPI25": {
    "nama": "Shopee Pay 25.000",
    "hargaid": 26500,
    "harga":"Rp26.500",
    },
        "SHPI30": {
    "nama": "Shopee Pay 30.000",
    "hargaid": 31500,
    "harga":"Rp31.500",
    },     
       "SHPI35": {
    "nama": "Shopee Pay 35.000",
    "hargaid": 36500,
    "harga":"Rp36.500",
    },     
       "SHPI40": {
    "nama": "Shopee Pay 40.000",
    "hargaid": 41500,
    "harga":"Rp41.500",
    },     
       "SHPI45": {
    "nama": "Shopee Pay 45.000",
    "hargaid": 46500,
    "harga":"Rp46.500",
    },     
      "SHPI50": {
    "nama": "Shopee Pay 50.000",
    "hargaid": 51500,
    "harga":"Rp51.500",
    },     
   "SHPI55": {
    "nama": "Shopee Pay 55.000",
    "hargaid": 56500,
    "harga":"Rp56.500",
    },     
   "SHPI60": {
    "nama": "Shopee Pay 60.000",
    "hargaid": 61500,
    "harga":"Rp61.500",
    },     
   "SHPI65": {
    "nama": "Shopee Pay 65.000",
    "hargaid": 66500,
    "harga":"Rp66.500",
    },     
   "SHPI70": {
    "nama": "Shopee Pay 70.000",
    "hargaid": 71500,
    "harga":"Rp71.500",
    },     
    "SHPI75": {
    "nama": "Shopee Pay 75.000",
    "hargaid": 76500,
    "harga":"Rp76.500",
    },     
   "SHPI80": {
    "nama": "Shopee Pay 80.000",
    "hargaid": 81500,
    "harga":"Rp81.500",
    },     
   "SHPI85": {
    "nama": "Shopee Pay 85.000",
    "hargaid": 86500,
    "harga":"Rp86.500",
    },     
   "SHPI90": {
    "nama": "Shopee Pay 90.000",
    "hargaid": 91500,
    "harga":"Rp91.500",
    },     
   "SHPI95": {
    "nama": "Shopee Pay 95.000",
    "hargaid": 96500,
    "harga":"Rp96.500",
    },     
   "SHPI100": {
    "nama": "Shopee Pay 100.000",
    "hargaid": 101.500,
    "harga":"Rp101.500",
    },     
   "SHPI200": {
    "nama": "Shopee Pay 200.000",
    "hargaid": 201500,
    "harga":"Rp201.500",
    },     
},
};

module.exports = { list3 }