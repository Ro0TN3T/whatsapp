const list30 = {
  "bulktsel": {   
    "BU1": {
    "nama": "Telkomsel Data Bulk 1 GB / 30 Hari (Kode:1)",
    "hargaid": 20000, 
    "harga":"Rp20.000",
    },       
    "BU2": {
    "nama":"Telkomsel Data Bulk 3 GB / 30 Hari (Kode:2)",
    "hargaid": 45000,
    "harga":"Rp45.000",
    },
    "BU3": {
    "nama":"Telkomsel Data Bulk 4.5 GB / 30 Hari (Kode:3)",
    "hargaid": 60000,
    "harga":"Rp60.000",
    },
    "BU4": {
    "nama":"Telkomsel Data Bulk 12 GB / 30 Hari (Kode:4)",
    "hargaid": 95000,
    "harga":"Rp95.000",
    },
    "BU5": {
    "nama":"Telkomsel Data Bulk 15 GB / 30 Hari(Kode:5)",
    "hargaid": 115000,
    "harga":"Rp115.000",
    },
    "BU6": {
    "nama":"Telkomsel Data Bulk 25 GB / 30 Hari (Kode:6)",
    "hargaid": 155000,
    "harga":"Rp155.000",
    },
},
};

module.exports = { list30 }

