const list34 = {
  "unlimitedmax": {   
    "UNX1": {
    "nama": "Telkomsel Data UnlimitedMax 30.000 (Kode:1)",
    "hargaid": 38000, 
    "harga":"Rp38.000",
    },       
    "UNX2": {
    "nama":"Telkomsel Data UnlimitedMax 50.000 (Kode:2)",
    "hargaid": 58000,
    "harga":"Rp58.000",
    },
    "UNX3": {
    "nama":"Telkomsel Data UnlimitedMax 70.000 (Kode:3)",
    "hargaid": 80000,
    "harga":"Rp80.000",
    },
},
};

module.exports = { list34 }

