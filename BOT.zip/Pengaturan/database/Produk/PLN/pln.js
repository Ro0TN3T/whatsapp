const list4 = {
  "pln": {   
    "PLN5": {
    "nama": "PLN 5.000",
    "hargaid": 6000,
    "harga":"Rp6.000",
    },
        "PLN10": {
    "nama": "PLN 10.000 ",
    "hargaid": 11000,
    "harga":"Rp11.000",
    },
        "PLN15": {
    "nama": "PLN 15.000",
    "hargaid": 16000,
    "harga":"Rp16.000",
    },
        "PLN20": {
    "nama": "PLN 20.000",
    "hargaid": 20400,
    "harga":"Rp20.400",
    },
        "PLN50": {
    "nama": "PLN 50.000",
    "hargaid": 50380,
    "harga":"Rp50.380",
    },
        "PLN100": {
    "nama": "PLN 100.000",
    "hargaid": 100380,
    "harga":"Rp100.380",
    },         
     "PLN200": {
    "nama": "PLN 200.000",
    "hargaid": 200380,
    "harga":"Rp200.380",
    },          
     "PLN500": {
    "nama": "PLN 500.000",
    "hargaid": 500380,
    "harga":"Rp500.380",
    },          
    "PLN1000000": {
    "nama": "PLN 1.000.000",
    "hargaid": 1000380,
    "harga":"Rp1.000.380",
    },          
},
};

module.exports = { list4 }