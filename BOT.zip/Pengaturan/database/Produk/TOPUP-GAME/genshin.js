const list55 = {
  "genshin": {   
     "GEN60": {
  "nama":"Genshin Impact 60 Genesis Crystals",
  "hargaid": 13000,
  "harga":"Rp13.000",
  },
  "GEN330": {
  "nama":"Genshin Impact 330 Genesis Crystals",
  "hargaid": 60000,
  "harga":"Rp60.000",
  },
    "GEN1090": {
    "nama": "Genshin Impact 1090 Genesis Crystals",
    "hargaid": 170000,
    "harga":"Rp170.000",
    },
    "GEN2240": {
    "nama":"Genshin Impact 3880 Genesis Crystals",
    "hargaid": 363000,
    "harga":"Rp363.000",
    },
        "GEN3880": {
    "nama": "Genshin Impact 3880 Genesis Crystals",
    "hargaid": 565000,
    "harga":"Rp565.000",
    },
    "GEN8080": {
    "nama":"Genshin Impact 8080 Genesis Crystals",
    "hargaid": 1200000,
    "harga":"Rp1.200.000",
    },
    "GEN1": {
    "nama":"Genshin Impact Blessing of the Welkin Moon Kode : 1",
    "hargaid": 60000,
    "harga":"Rp60.000",
    },
},
};

module.exports = { list55 }

