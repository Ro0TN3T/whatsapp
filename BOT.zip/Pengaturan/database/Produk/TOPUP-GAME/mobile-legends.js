const list10 = {
  "ml": {   
    "ML1": {
    "nama": "Mobile Lengeds Weekly Diamond Pass Kode:1",
    "hargaid": 25000,
    "harga":"Rp25.000",
    },
    "ML2": {
    "nama": "Mobile Lengeds Starlinght Member Kode:2",
    "hargaid": 135000,
    "harga":"Rp135.000",
    },
    "ML3": {
    "nama": "Mobile Lengeds Twilight Pass Kode:3",
    "hargaid": 115000,
    "harga":"Rp115.000",
    },
    "ML5": {
    "nama": "5 Diamond Mobile Legends",
    "hargaid": 1500,
    "harga":"Rp1.500",
    },
        "ML12": {
    "nama": " 12 Diamond Mobile Legends ",
    "hargaid": 3500,
    "harga":"Rp3.500",
    },
        "ML19": {
    "nama": "19 Diamond Mobile Legends",
    "hargaid": 5700,
    "harga":"Rp5.700",
    },
        "ML28": {
    "nama": " 28 Diamond Mobile Legends",
    "hargaid": 6800,
    "harga":"Rp6.800",
    },
       "ML36": {
    "nama": "36 Diamond Mobile Legends",
    "hargaid": 9900,
    "harga":"Rp9.900",
    },
    "ML44": {
    "nama": "44 Diamond Mobile Legends",
    "hargaid": 11710,
    "harga":"Rp11.710",
    },
    "ML56": {
    "nama": "56 Diamond Mobile Legends",
    "hargaid": 13700,
    "harga":"Rp13.700",
    },
        "ML59": {
    "nama": "59 Diamond Mobile Legends",
    "hargaid": 14500,
    "harga":"Rp14.500",
    },
    "ML75": { 
    "nama": "75 Diamond Mobile Lengeds",
    "hargaid": 17400,
    "harga":"Rp17.400",
    },
    "ML86": {
    "nama": "86 Diamond Mobile Legends",
    "hargaid": 19500,
    "harga":"Rp19.500",
    },
    "ML100": {
    "nama": "100 Diamond Mobile Lengeds",
    "hargaid": 23700,
    "harga":"Rp23.700",
    },
    "ML112": {
    "nama": "112 Diamond Mobile Legends",
    "hargaid": 25500,
    "harga":"Rp25.500",
    },
    "ML140": {
    "nama":"140 Diamond Mobile Lengeds",
    "hargaid": 33400,
    "harga":"Rp33.400",
    },
    "ML150": {
    "nama":"150 Diamond Mobile Lengeds",
    "hargaid": 35100,
    "harga":"Rp35.100",
    },
    "ML172": {
    "nama": "172 Diamond Mobile Legends",
    "hargaid": 38300,
    "harga":"Rp38.300",
    },
    "ML185": {
    "nama": "185 Diamond Mobile Legends",
    "hargaid": 44200,
    "harga":"Rp43.200",
    },
    "ML200": {
    "nama": "200 Diamond Mobile Lengeds",
    "hargaid": 45500,
    "harga":"Rp45.500",
    },
    "ML250": {
    "nama": "250 Diamond Mobile Lengeds",
    "hargaid": 58400,
    "harga":"Rp58.400",
    },
    "ML257": {
    "nama": "257 Diamond Mobile Legends",
    "hargaid": 59300,
    "harga":"Rp59.300",
    },            
     "ML284": {
    "nama": "284 Diamond Mobile Legends",
    "hargaid": 64300,
    "harga":"Rp64.300",
    },       
    "ML296": {
    "nama":"296 Diamond Mobile Lengeds",
    "hargaid": 65900,
    "harga":"Rp65.900",
    },
     "ML344": {
    "nama":"344 Diamond Mobile Legends",
    "hargaid": 74200,
    "harga":"Rp74.200",
    },       
    "ML370": {
    "nama":"370 Diamond Mobile Lengeds",
    "hargaid": 83200,
    "harga":"Rp83.200",
    },
    "ML408": {
    "nama":"408 Diamond Mobile Lengeds",
    "hargaid": 88200,
    "harga":"Rp88.200",
    },
     "ML429": {
    "nama": "429 Diamond Mobile Legends",
    "hargaid": 90000,
    "harga":"Rp90.000",
    },       
     "ML514": {
    "nama": "514 Diamond Mobile Legends",
    "hargaid": 112200,
    "harga":"Rp112.200",
    },       
    "ML568": {
    "nama":"568 Diamond Mobile Lengeds",
    "hargaid": 122100,
    "harga":"Rp122.100",
   },
     "ML600": {
    "nama": "600 Diamond Mobile Legends",
    "hargaid": 130300,
    "harga":"Rp130.300",
    },       
     "ML706": {
    "nama": "706 Diamond Mobile Legends",
    "hargaid": 151200,
    "harga":"Rp151.200",
    },       
    "ML878": {
    "nama": "878 Diamond Mobile Lengeds",
    "hargaid": 183800,
    "harga":"Rp183.800",
    },
    "ML1000": {
    "nama":"1000 Diamond Mobile Lengeds",
    "hargaid": 210200,
    "harga":"Rp210.200",
    },
    "ML1159": {
    "nama":"1159 Diamond Mobile Lengeds",
    "hargaid": 250000,
    "harga":"Rp250.000",
    },
    "ML1446": {
    "nama":"1446 Diamond Mobile Lengeds",
    "hargaid": 305000,
    "harga":"Rp305.000",
    },
    "ML2010": {
    "nama":"2010 Diamond Mobile Lengeds",
    "hargaid": 430000,
    "harga":"Rp430.000",
   },
},
};

module.exports = { list10 }

