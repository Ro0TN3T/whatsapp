const list12 = {
  "ff": {   
     "F1": {
  "nama":"Free Fire Membership Mingguan Kode:1",
  "hargaid": 26000,
  "harga":"Rp26.000",
  },
  "F2": {
  "nama":"Free Fire Membership Bulanan Kode:2",
  "hargaid": 80670,
  "harga":"Rp80.670",
  },
    "F5": {
    "nama": "5 Diamond Free Fire",
    "hargaid": 880,
    "harga":"Rp880",
    },
    "F10": {
    "nama":"10 Diamond Free Fire",
    "hargaid": 1670,
    "harga":"Rp1.670",
    },
        "F12": {
    "nama": "12 Diamond Free Fire ",
    "hargaid": 2000,
    "harga":"Rp2.000",
    },
    "F20": {
    "nama":"20 Diamond Free Fire",
    "hargaid": 3.890,
    "harga":"Rp3.890",
    },
    "F30": {
    "nama":"30 Diamond Free Fire",
    "hargaid": 5140,
    "harga":"Rp5.140",
    },
        "F50": {
    "nama": "50 Diamond Free Fire",
    "hargaid": 6980,
    "harga":"Rp6.980",
    },
    "F60": {
    "nama":"60 Diamond Free Fire",
    "hargaid": 8600,
    "harga":"Rp8.600",
    },
        "F70": {
    "nama": "70 Diamond Free Fire",
    "hargaid": 9145,
    "harga":"Rp9.145",
    },
    "F80": {
    "nama":"80 Diamond Free Fire",
    "hargaid": 10567,
    "harga":"Rp10.567",
    },
    "F90": {
    "nama":"90 Diamond Free Fire",
    "hargaid": 11567,
    "harga":"Rp11.567",
    },
       "F100": {
    "nama": "100 Diamond Free Fire",
    "hargaid": 13565,
    "harga":"Rp13.565",
    },
    "F140": {
    "nama": "140 Diamond Free Fire",
    "hargaid": 17700,
    "harga":"Rp17.700",
    },
    "F180": {
    "nama":"180 Diamond Free Fire",
    "hargaid": 24345,
    "harga":"Rp24.345",
    },
    "F210": {
    "nama": "210 Diamond Free Fire",
    "hargaid": 26870,
    "harga":"Rp26.870",
    },
    "F250": {
    "nama":"250 Diamond Free Fire",
    "hargaid": 31850,
    "harga":"Rp31.850",
    },
    "F300": {
    "nama":"300 Diamond Free Fire",
    "hargaid": 38230,
    "harga":"Rp38.230",
    },
        "F355": {
    "nama": "355 Diamond Free Fire",
    "hargaid": 43870,
    "harga":"Rp43.870",
    },
    "F375": {
   "nama":"375 Diamond Free Fire",
   "hargaid": 46480,
   "harga":"Rp46.480",
   },
   "F400": {
   "nama":"400 Diamond Free Fire",
   "hargaid": 49890,
   "harga":"Rp49.980",
   },
   "F425": {
   "nama":"425 Diamond Free Fire",
   "hargaid": 50.870,
   "harga":"Rp50.870",
   },
   "F475": {
   "nama":"475 Diamond Free Fire",
   "hargaid": 58400,
   "harga":"Rp58.400",
   },
    "F500": {
    "nama":"500 Diamond Free Fire",
    "hargaid": 62430,
    "harga":"Rp62.430",
    },
    "F600": {
    "nama":"600 Diamond Free Fire",
    "hargaid": 74450,
    "harga":"Rp74.450",
    },
    "F720": {
    "nama": "720 Diamond Free Fire",
    "hargaid": 86560,
    "harga":"Rp86.560",
    },
    "F740": {
    "nama":"740 Diamond Free Fire",
    "hargaid": 90745,
    "harga":"Rp90.745",
    },
    "F800": {
    "nama":"800 Diamond Free Fire",
    "hargaid": 98670,
    "harga":"Rp98.670",
    },
    "F930": {
    "nama":"930 Diamond Free Fire",
    "hargaid": 115000,
    "harga":"Rp115.000",
    },
    "F1000": {
    "nama": "1000 Diamond Free Fire",
    "hargaid": 120456,
    "harga":"Rp120.456",
    },
    "F1080": {
    "nama":"1080 Diamond Free Fire",
    "hargaid": 128870,
    "harga":"Rp128.870",
   },
    "F1450": {
    "nama": "1450 Diamond Free Fire",
    "hargaid": 172.450,
    "harga":"Rp172.450",
    },
    "F2355": {
    "nama":"2355 Diamond Free Fire",
    "hargaid": 280560,
    "harga":"Rp280.560",
    },
        "F3640": {
    "nama": "3640 Diamond Free Fire",
    "hargaid": 431330,
    "harga":"Rp431.330",
    },            
},
};

module.exports = { list12 }

