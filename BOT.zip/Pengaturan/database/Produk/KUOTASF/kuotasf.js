const list19 = {
  "kuotasf": {   
    "SF1": {
    "nama": "Smartfren Data Kuota M (Kode:1)",
    "hargaid": 32000,
    "harga":"Rp32.000",
    },       
    "SF2": {
    "nama":"Smartfren Data Kuota L (Kode:2)",
    "hargaid": 48000,
    "harga":"Rp48.000",
    },
    "SF3": {
    "nama":"Smartfren Data Kuota 2L (Kode:3)",
    "hargaid": 74000,
    "harga":"Rp74.000",
    },
    "SF4": {
    "nama":"Smartfren Data Kuota 3L (Kode:4)",
    "hargaid": 103000,
    "harga":"Rp103.000",
    },
       "SF5": {
    "nama":"Smartfren Data Kuota 4L (Kode:5)",
    "hargaid": 125000,
    "harga":"Rp125.000",
    },   
},
};

module.exports = { list19 }

