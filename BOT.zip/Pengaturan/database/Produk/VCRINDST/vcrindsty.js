const list49 = {
  "vcrindsty": {   
    "VINDSTY1": {
    "nama": "Voucher Indosat Yellow 1GB 7Hr (Kode:1)",
    "hargaid": 43000, 
    "harga":"Rp43.000",
    },       
},
};

module.exports = { list49 }