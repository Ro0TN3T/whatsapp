const list47 = {
  "vcrthappy": {   
    "VHAPPY1": {
    "nama": "Voucher Tri Happy 1 GB / 3 Hari (Kode:1)",
    "hargaid": 7200, 
    "harga":"Rp7.200",
    },       
    "VHAPPY2": {
    "nama": "Voucher Tri Happy 3 GB / 3 Hari (Kode:2)",
    "hargaid": 10500, 
    "harga":"Rp10.500",
    },   
    "VHAPPY3": {
    "nama": "Voucher Tri Happy 5 GB / 3 Hari (Kode:3)",
    "hargaid": 13500, 
    "harga":"Rp13.500",
    },       
    "VHAPPY4": {
    "nama": "Voucher Tri Happy 7 GB / 30 Hari (Kode:4)",
    "hargaid": 27300, 
    "harga":"Rp27.300",
    },   
    "VHAPPY5": {
    "nama": "Voucher Tri Happy 11 GB / 30 Hari (Kode:5)",
    "hargaid": 40500, 
    "harga":"Rp40.500",
    },   
    "VHAPPY6": {
    "nama": "Voucher Tri Happy 18 GB / 30 Hari (Kode:6)",
    "hargaid": 56000, 
    "harga":"Rp56.000",
    },   
},
};

module.exports = { list47 }