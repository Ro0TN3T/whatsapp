const list40 = {
  "miniaxis": {   
    "AXM1": {
    "nama": "Axis Data Mini 3.5 GB / 7 Hari (Kode:1)",
    "hargaid": 2000,
    "harga":"Rp20.000",
    },       
    "AXM2": {
    "nama":"Axis Data Mini 4.5 GB / 7 Hari (Kode:2)",
    "hargaid": 25000,
    "harga":"Rp25.000",
    },
    "AXM3": {
    "nama":"Axis Data Mini 6 GB / 7 Hari (Kode:3)",
    "hargaid": 30000,
    "harga":"Rp30.000",
    },
     "AXM4": {
    "nama":"Axis Data Mini 4 GB / 15 Hari (Kode:3)",
    "hargaid": 32000,
    "harga":"Rp32.000",
    },
 "AXM5": {
    "nama":"Axis Data Mini 8 GB / 15 Hari (Kode:3)",
    "hargaid": 45000,
    "harga":"Rp45.000",
    },
},
};

module.exports = { list40 }

