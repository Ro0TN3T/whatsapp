const list50 = {
  "vcraxismini": {   
    "VAXISM1": {
    "nama": "Voucher Axis Data Mini 1.5 GB / 5 Hari (Kode:1)",
    "hargaid": 43000, 
    "harga":"Rp43.000",
    },       
    "VAXISM2": {
    "nama": "Voucher Axis Data Mini 2 GB / 5 Hari (Kode:2)",
    "hargaid": 74000, 
    "harga":"Rp74.000",
    },   
    "VAXISM3": {
    "nama": "Voucher Axis Data Mini 3 GB / 5 Hari (Kode:3)",
    "hargaid": 95000, 
    "harga":"Rp95.000",
    },       
    "VAXISM4": {
    "nama": "Voucher Axis Data Mini 5 GB / 5 Hari (Kode:4)",
    "hargaid": 105000, 
    "harga":"Rp105.000",
    },   
    "VAXISM5": {
    "nama": "Voucher Axis Data Mini 2 GB / 7 Hari (Kode:5)",
    "hargaid": 105000, 
    "harga":"Rp105.000",
    },   
},
};

module.exports = { list50 }