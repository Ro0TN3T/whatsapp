const list20 = {
  "xtracombo": {   
    "XT8": {
    "nama": "XL Xtra Combo Special 8 GB / 30 Hari (Kode:8)",
    "hargaid": 25000,
    "harga":"Rp25.000",
    },       
    "XT14": {
    "nama":"XL Xtra Combo Special 14 GB / 30 Hari (Kode:14)",
    "hargaid": 35000,
    "harga":"Rp35.000",
    },
    "XT6": {
    "nama":"XL Xtra Combo 2 GB + 4 GB / 30 Hari (Kode:6)",
    "hargaid": 28000,
    "harga":"Rp28.000",
    },
    "XT15": {
    "nama":"XL Xtra Combo 5 GB + 10 GB / 30 Hari (Kode:15)",
    "hargaid": 55000,
    "harga":"Rp55.000",
    },
       "XT30": {
    "nama":"XL Xtra Combo 10 GB + 20 GB / 30 Hari (Kode:30)",
    "hargaid": 88000,
    "harga":"Rp88.000",
    },
    "XT45": {
    "nama":"XL Xtra Combo 15GB + 30 GB / 30 Hari (Kode:30)",
    "hargaid": 120000,
    "harga":"Rp120.000",
    },   
},
};

module.exports = { list20 }

