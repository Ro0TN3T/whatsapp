const list21 = {
  "xtracombolite": {   
    "CT1": {
    "nama": "XL Combo Lite S (Kode:1)",
    "hargaid": 23000,
    "harga":"Rp23.000",
    },       
    "CT2": {
    "nama":"XL Combo Lite M (Kode:2)",
    "hargaid": 30000,
    "harga":"Rp30.000",
    },
    "CT3": {
    "nama":"XL Combo Lite L (Kode:3)",
    "hargaid": 58000,
    "harga":"Rp58.000",
    },
    "CT4": {
    "nama":"XL Combo Lite XXL (Kode:4)",
    "hargaid": 105000,
    "harga":"Rp105.000",
    },
       "CT5": {
    "nama":"XL Combo Lite XL (Kode:5)",
    "hargaid": 80000,
    "harga":"Rp80.000",
    },   
    "CT6": {
    "nama":"XL Combo Lite XXXL (Kode:6)",
    "hargaid": 130000,
    "harga":"Rp130.000",
    },   
},
};

module.exports = { list21 }

