const list23 = {
  "minixl": {   
    "MX1": {
    "nama": "XL Data Mini 1 GB / 7 Hari (Kode:1)",
    "hargaid": 9800,
    "harga":"Rp9.800",
    },       
    "MX2": {
    "nama":"XL Data Mini 2.5 GB / 7 Hari (Kode:2)",
    "hargaid": 15000,
    "harga":"Rp15.000",
    },
    "MX3": {
    "nama":"XL Data Mini 4 GB / 7 Hari (Kode:3)",
    "hargaid": 17000,
    "harga":"Rp17.000",
    },
},
};

module.exports = { list23 }

