const list37 = {
  "freedominternet": {   
    "FRT1": {
    "nama": "Indosat Freedom Internet 3 GB / 30 Hari (Kode:1)",
    "hargaid": 20000, 
    "harga":"Rp20.000",
    },       
    "FRT2": {
    "nama":"Indosat Freedom Internet 5,5 GB / 30 Hari (Kode:2)",
    "hargaid": 34000,
    "harga":"Rp34.000",
    },
    "FRT3": {
    "nama":"Indosat Freedom Internet 9 GB / 30 Hari (Kode:3)",
    "hargaid": 45000,
    "harga":"Rp45.000",
    },
    "FRT4": {
    "nama":"Indosat Freedom Internet 10 GB / 30 Hari (Kode:4)",
    "hargaid": 50000,
    "harga":"Rp50.000",
    },
    "FRT5": {
    "nama":"Indosat Freedom Internet 13 GB / 30 Hari (Kode:5)",
    "hargaid": 62000,
    "harga":"Rp62.000",
    },
     "FRT6": {
    "nama":"Indosat Freedom Internet 20 GB / 30 Hari (Kode:6)",
    "hargaid": 85000,
    "harga":"Rp85.000",
    },
    "FRT7": {
    "nama":"Indosat Freedom Internet 25 GB / 30 Hari (Kode:7)",
    "hargaid": 95000,
    "harga":"Rp95.000",
    },
    "FRT8": {
    "nama":"Indosat Freedom Internet 30 GB / 30 Hari (Kode:8)",
    "hargaid": 115000,
    "harga":"Rp115.000",
    },
},
};

module.exports = { list37 }

