const list35 = {
  "yellow": {   
    "YEL1": {
    "nama": "Indosat Yellow 700 MB / 1 Hari (Kode:1)",
    "hargaid": 5000, 
    "harga":"Rp5.000",
    },       
    "YEL2": {
    "nama":"Indosat Yellow 1 GB / 1 Hari (Kode:2)",
    "hargaid": 7000,
    "harga":"Rp7.000",
    },
    "YEL3": {
    "nama":"Indosat Yellow 1 GB / 2 Hari (Kode:3)",
    "hargaid": 8000,
    "harga":"Rp8.000",
    },
    "YEL4": {
    "nama":"Indosat Yellow 1 GB / 3 Hari (Kode:4)",
    "hargaid": 10000,
    "harga":"Rp10.000",
    },
    "YEL5": {
    "nama":"Indosat Yellow 2 GB / 3 Hari (Kode:5)",
    "hargaid": 13000,
    "harga":"Rp13.000",
    },
    "YEL6": {
    "nama":"Indosat Yellow 3 GB / 3 Hari (Kode:6)",
    "hargaid": 16000,
    "harga":"Rp16.000",
    },
    "YEL7": {
    "nama":"Indosat Yellow 1 GB / 7 Hari (Kode:7)",
    "hargaid": 18000,
    "harga":"Rp18.000",
    },
    "YEL8": {
    "nama":"Indosat Yellow 2 GB / 7 Hari (Kode:8)",
    "hargaid": 20000,
    "harga":"Rp20.000",
    },
    "YEL9": {
    "nama":"Indosat Yellow 3 GB / 7 Hari (Kode:9)",
    "hargaid": 22000, 
    "harga":"Rp22.000",
    },
    "YEL10": {
    "nama":"Indosat Yellow 1 GB / 15 Hari (Kode:10)",
    "hargaid": 25000, 
    "harga":"Rp25.000",
    },
},
};

module.exports = { list35 }

