const list39 = {
  "freedomu": {   
    "FRU1": {
    "nama": "Indosat Freedom U 1 GB + 4.5 GB Apps / 30 Hari (Kode:1)",
    "hargaid": 28000, 
    "harga":"Rp28.000",
    },       
    "FRU2": {
    "nama":"Indosat Freedom U 2 GB + 8 GB Apps / 30 Hari (Kode:2)",
    "hargaid": 48000,
    "harga":"Rp48.000",
    },
    "FRU3": {
    "nama":"Indosat Freedom U 3 GB + 17 GB Apps / 30 Hari (Kode:3)",
    "hargaid": 70000,
    "harga":"Rp70.000",
    },
     "FRU4": {
    "nama":"Indosat Freedom U 10 GB + 35 GB Apps / 30 Hari (Kode:4)",
    "hargaid": 100000,
    "harga":"Rp100.000",
    },
},
};

module.exports = { list39 }

