const ariekey = 'bm7vIOIlzUPscwqMU2aL0WJSki5WfHqJ' // INPUT API KEY https://ariepulsa.com
const nomorKu = '6282376666188@s.whatsapp.net'

module.exports = {
    ariekey,
    nomorKu
}